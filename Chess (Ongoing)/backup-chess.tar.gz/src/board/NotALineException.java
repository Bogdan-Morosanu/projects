package board;

public class NotALineException extends Exception {
	NotALineException(String msg){
		super(msg);
	}
}
