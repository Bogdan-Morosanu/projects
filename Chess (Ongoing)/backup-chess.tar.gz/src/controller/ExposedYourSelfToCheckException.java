package controller;

public class ExposedYourSelfToCheckException extends Exception {
	ExposedYourSelfToCheckException(String msg) {
		super(msg);
	}
}
