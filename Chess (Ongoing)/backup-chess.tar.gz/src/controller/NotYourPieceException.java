package controller;

public class NotYourPieceException extends Exception {
	public NotYourPieceException(String msg) {
		super(msg);
	}
}
