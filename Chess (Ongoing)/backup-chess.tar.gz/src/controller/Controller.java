package controller;

import board.InvalidPositionException;
import board.Map;
import board.Position;
import board.PositionList;
import pieces.King;
import pieces.Knight;
import pieces.Pawn;
import pieces.Piece;
import pieces.PieceList;

public class Controller {
	
	public enum GameStatus {
		WHITE_WIN, BLACK_WIN, DRAW, ONGOING;
		
		public String toString() {
			switch(this) {
				case WHITE_WIN: return "White wins!";
				case BLACK_WIN: return "Black wins!";
				case DRAW: return "Draw!";
				default: return "Ongoing!";
			}
		}
	}
	
	public enum Player {
		WHITE, BLACK;
		
		public Piece.Color toPieceColor() {
			if(this == WHITE) {
				return Piece.Color.WHITE;
			} else {
				return Piece.Color.BLACK;
			}
		}
	}
	
	private static GameStatus gameStatus = GameStatus.ONGOING;
	private static boolean whiteInCheck = false;
	private static boolean whiteTrapped = false;
	private static boolean blackInCheck = false;
	private static boolean blackTrapped = false;
	private static Player toMove = Player.WHITE;
	private static final boolean DEBUG = true;
	private static Pawn pawnToBePromoted = null;
	
	
	public static GameStatus checkStatus() {
		
		Controller.pawnToBePromoted = findPawnPromotion();
		
		Map map = AppRegistry.getMap();
		King whiteKing = AppRegistry.getWhiteKing();
		King blackKing = AppRegistry.getBlackKing();
		
		Controller.whiteInCheck = computeCheckStatus(whiteKing);
		Controller.blackInCheck = computeCheckStatus(blackKing);
		
		Controller.whiteTrapped = computeTrapStatus(whiteKing);
		Controller.blackTrapped = computeTrapStatus(blackKing);
		
		
		if(isCheckMated(whiteKing)) {
			return GameStatus.BLACK_WIN;
		} 
		
		if(isCheckMated(blackKing)) {
			return GameStatus.WHITE_WIN;
		} 
		
		if(whiteTrapped || blackTrapped) return GameStatus.DRAW;
		
		return GameStatus.ONGOING;
	}
	
	public static boolean isCheckMated(King k) {
		if(isInCheck(k) && isKingTrapped(k)) {
			//we must get possible defenders
			Map map = AppRegistry.getMap();
			
			PieceList attackers = 
					map.getPossibleAttackersOfColor(k,k.getColor().getAdversary());
			
			if(attackers.size() > 1) {
				//King is forked, block impossible, checkmate
				return true;
			}
			
			//otherwise this is our sole attacker
			Piece attacker = attackers.get(0);
			
			PositionList toBlock = null;
			
			try {
				if(attacker instanceof Knight) {
					//no line between king and Knigth!
					toBlock = new PositionList();
					toBlock.add(attacker.getPosition());
				
				} else {
					toBlock = map.getPositionLine(k.getPosition(), attacker.getPosition());
				}
			} catch(InvalidPositionException e) {
				//technically impossible, unless map data is corrupt
				System.out.println(e.getMessage());
			}
			
			for(Position pos : toBlock) {
				PieceList defenders = map.getPossibleAttackersOfColor(pos, k.getColor());
				if(defenders.size() > 0) {
					if(defenders.size() == 1 && defenders.get(0) == k) {
						//it looks like we are the sole defender
						return true; //tough luck
					}
					return false; //we have found our defender!
				}
			}
			
			return true; //nobody to defend, trapped and in check
		} else {
			return false; //not trapped
		}
	}
	
	public static boolean isInCheck(King k) {
		return (k.getColor() == Piece.Color.WHITE) ? whiteInCheck : blackInCheck;
	}
	
	public static boolean computeCheckStatus(King k) {
		
		if(DEBUG) System.out.println("\nfor " + k);
		
		Map map = AppRegistry.getMap();
		PieceList attackers = map.getPossibleAttackers(k);
		
		if(DEBUG) for(Piece attacker : attackers) {
			System.out.println(attacker.toString() );
		}
		
		if(attackers.containsColor(k.getAdversaryColor())) {
			return true;
		}
		
		return false;
	}
	
	public static boolean computeTrapStatus(King k) {
		//we are under fire, must see if King can move to different place
		System.out.println("looking for escapes for : " + k);
		Map map = AppRegistry.getMap();
		PositionList possibleEscapes = map.getSurroundingConstPositions(k.getPosition());
		for(Position escape : possibleEscapes) {
			System.out.println("testing for escape @ " + escape);
			if(escape != null && k.moveTypePermitted(escape)) {
				return false;
			}
		}
		
		return true;
	}
	
	public static boolean isKingTrapped(King k) {
		return (k.getColor() == Piece.Color.WHITE) ? whiteTrapped : blackTrapped;
	}
	
	public static Pawn findPawnPromotion() {
		
		
		Map map = AppRegistry.getMap();
		Position cornerNW = AppRegistry.getConstPosition(0, 0);
		Position cornerNE = AppRegistry.getConstPosition(0, 7);
		Position cornerSE = AppRegistry.getConstPosition(7, 7);
		Position cornerSW = AppRegistry.getConstPosition(7, 0);

		try {
			//see for black pawns
			
			PieceList firstLine = map.getPieceLinePlusOrigin(cornerNW,cornerNE);
			
			for(Piece p : firstLine) {

				if(p instanceof Pawn && p.getColor() == Piece.Color.BLACK) {
					return (Pawn)p;
				}
			}
			
		} catch(InvalidPositionException e) {
			//can't technically happen
			System.out.println(e.getMessage() + " : called from pawn promotion method in controller");
		}
		
		
		try {
			//check for white pawns
			PieceList lastLine = map.getPieceLinePlusOrigin(cornerSW,cornerSE);
			for(Piece p : lastLine) {
				if(p instanceof Pawn && p.getColor() == Piece.Color.WHITE) {
					return (Pawn)p;

				}
			}
		} catch(InvalidPositionException e) {
			//can't technically happen
			System.out.println(e.getMessage() + " : called from pawn promotion method in controller");
		}
		
		return null; 
	}
	
	public static Pawn pawnPromotionDue() {
		return Controller.pawnToBePromoted;
	}
	
	public static void doPawnPromotion(Class<? extends Piece> choice) {
		Map map = AppRegistry.getMap();
		Piece.Color color = Controller.pawnToBePromoted.getColor();
		Position pos = Controller.pawnToBePromoted.getPosition();
		
		Piece replacerPiece = Piece.createPiece(choice,color,pos);
		
		map.setPieceAt(pos, replacerPiece);
		
		Controller.pawnToBePromoted = null; //reset promotion
	}
	
	public static Player getNextPlayer() {
		if(toMove == Player.WHITE) {
			return Player.BLACK;
		} else {
			return Player.WHITE;
		}
	}
	
	public static void executeTurnActions() {
		if(Executor.executeNext()) {
			Controller.toMove = getNextPlayer();	
			Controller.gameStatus = checkStatus();
		}
	}
	
	public static void undoTurnActions() {
		if(Executor.undoLast()) {	
			Controller.toMove = getNextPlayer();
			Controller.gameStatus = checkStatus();
		}
	}
	
	 
	public String toString() {
		String str = "Status : " + Controller.gameStatus + "\n";
		str += "white in check : " + Controller.whiteInCheck + "\n";
		str += "black in check : " + Controller.blackInCheck + "\n";
		str += "toMove : " + Controller.toMove + "\n";
		
		return str;		
	}
	
	public static Player getCurrentPlayer() {
		return Controller.toMove;
	}
	
	public static Player getWinner() {
		switch(gameStatus){
			case WHITE_WIN : return Player.WHITE;
			case BLACK_WIN : return Player.BLACK;
			default : return null;
		}
	}
	
	public static void main(String[] args) {
		Map map = AppRegistry.getMap();
		Controller cnt = new Controller();
		System.out.println(map);
		
		Executor.setChangesVisible(true);
		
		while(!Executor.finishedExecuting()) {
			Controller.executeTurnActions();
			System.out.println(cnt);
			
		}
		
		Executor.undoLast();
		Executor.undoLast();
		Executor.undoLast();
	}

}
