javadoc -private ../src/board/*.java ../src/controller/*.java ../src/pieces/*.java ../src/views/*.java ../src/ai/*.java ../src/ai/BitModel/*.java ../src/ai/AlphaBeta/*.java

